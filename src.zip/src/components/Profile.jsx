import React from 'react';
import s from './Profile.module.css';

const Profile = () => {
    return <div className={s.content}>
    <div>
      <img src='https://www.ladymakeup.com/js/lightbox/img/demopage/image-3.jpg'/>
    </div>
    <div>
      <img src='https://thumbs.dreamstime.com/b/cosmos-beauty-deep-space-elements-image-furnished-nasa-science-fiction-art-102581846.jpg'/>
    </div>
    <div>
      Ava + Description
    </div>
    <div>
      My posts
    </div>
    <div>
      New post
    </div>
    <div className={s.posts}>
      <div className={s.item}>
        post 1
      </div>
      <div className={s.item}>
        post 2
      </div>
    </div>
  </div>
}

export default Profile;