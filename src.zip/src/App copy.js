import React from 'react';
import './App.css';

const App = () => {
  return (
    <div className='app-wrapper'>
      <header className='header'>
      </header>

        <nav className='nav'>
          <div>
            <a>Profile</a>
          </div>
          <div>
            <a>Messages</a>
          </div>
          <div>
            <a>News</a>
          </div>
          <div>
            <a>Music</a>
          </div>
          <div>
            <a>Settings</a>
          </div>
        </nav>

    <div className='content'>
      <div>
        <img src=''/>
      </div>
      <div>
        
      </div>
    </div>

    </div>)
}